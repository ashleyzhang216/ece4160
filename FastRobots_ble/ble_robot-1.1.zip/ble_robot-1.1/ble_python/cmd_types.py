from enum import Enum

class CMD(Enum):
    # PING = 0
    # SEND_TWO_INTS = 1
    # SEND_THREE_FLOATS = 2
    # ECHO = 3
    # DANCE = 4
    # SET_VEL = 5
    # GET_TIME_MILLIS = 6
    # GET_MANY_TIME_MILLIS = 7
    # SEND_TIME_DATA = 8
    # GET_TEMP_READINGS = 9
    # GET_ROLL_PITCH = 10
    # GET_GYRO_DATA = 11
    # GET_ACC_GYRO_DATA = 12
    # GET_DIST_DATA = 13
    # ADJUST_PWM_VALS = 14
    # BRAKE_MOTORS = 15
    # GET_PID_DATA = 16
    # MOVE_FORWARD_TIMED = 17
    # MOVE_WHEELS_TIMED = 18
    # PID_TO_WALL = 19
    # CHANGE_SETPOINT = 20
    # PID_YAW = 21
    PING = 0
    ECHO = 1
    MOVE_WHEELS_TIMED = 2